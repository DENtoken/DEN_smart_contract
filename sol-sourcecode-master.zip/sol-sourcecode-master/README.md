# sol-sourcecode
Bears the full stacked solidity source code for DENtoken
